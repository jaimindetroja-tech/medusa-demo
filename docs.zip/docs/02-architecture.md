# 🏗️ System Architecture

## 📐 Component Overview

The product sync system consists of several interconnected components:

```
┌─────────────────────────────────────────────────────────────────┐
│                        MEDUSA FRAMEWORK                         │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    SCHEDULED JOB                          │  │
│  │              sync-products.ts                             │  │
│  │  • Cron: "0 0 * * *" (Daily at midnight)                 │  │
│  │  • Entry point for sync process                          │  │
│  └───────────┬───────────────────────────────────────────────┘  │
│              │                                                   │
│              ▼                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                  UTILITY LIBRARIES                        │  │
│  │  ┌─────────────────────┐  ┌──────────────────────────┐   │  │
│  │  │   retry.ts          │  │  batch-processor.ts      │   │  │
│  │  │                     │  │                          │   │  │
│  │  │ • fetchWithRetry()  │  │ • batchGenerator()       │   │  │
│  │  │ • Exponential       │  │ • Async iterator         │   │  │
│  │  │   backoff           │  │ • Memory-efficient       │   │  │
│  │  │ • Max 3 retries     │  │ • Batch size: 15         │   │  │
│  │  └─────────────────────┘  └──────────────────────────┘   │  │
│  └───────────────────────────────────────────────────────────┘  │
│              │                                                   │
│              ▼                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    WORKFLOWS                              │  │
│  │  ┌─────────────────────┐  ┌──────────────────────────┐   │  │
│  │  │ sync-categories.ts  │  │ Medusa Core Workflows    │   │  │
│  │  │                     │  │                          │   │  │
│  │  │ • syncCategoriesWF  │  │ • createProductsWF       │   │  │
│  │  │ • Check existing    │  │ • updateProductsWF       │   │  │
│  │  │ • Create new        │  │ • Built-in workflows     │   │  │
│  │  │ • Return map        │  │                          │   │  │
│  │  └─────────────────────┘  └──────────────────────────┘   │  │
│  └───────────────────────────────────────────────────────────┘  │
│              │                                                   │
│              ▼                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                  DATA LAYER                               │  │
│  │  ┌─────────────────────┐  ┌──────────────────────────┐   │  │
│  │  │   Query Service     │  │   Database (PostgreSQL)  │   │  │
│  │  │                     │  │                          │   │  │
│  │  │ • query.graph()     │  │ • Products               │   │  │
│  │  │ • Fetch existing    │  │ • Categories             │   │  │
│  │  │   products          │  │ • Variants               │   │  │
│  │  │ • Fetch categories  │  │ • Metadata               │   │  │
│  │  └─────────────────────┘  └──────────────────────────┘   │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌──────────────────┐
                    │  DummyJSON API   │
                    │                  │
                    │ • GET /products  │
                    │ • Pagination     │
                    │ • 194 products   │
                    └──────────────────┘
```

---

## 🧩 Component Details

### 1. **Scheduled Job** (`sync-products.ts`)

**Purpose**: Main orchestrator that coordinates the entire sync process

**Responsibilities**:
- Trigger on cron schedule
- Fetch all products from external API
- Sync categories
- Transform data
- Separate creates vs updates
- Process in batches
- Log progress and errors

**Key Functions**:
```typescript
export default async function syncProductsJob(container: MedusaContainer)
```

**Configuration**:
```typescript
export const config = {
    name: "sync-products",
    schedule: "0 0 * * *", // Daily at midnight
}
```

---

### 2. **Retry Utility** (`lib/retry.ts`)

**Purpose**: Handle network failures with exponential backoff

**Architecture**:
```
Request Attempt 1
    │
    ├─ Success? → Return data
    │
    └─ Failure? → Wait 1000ms
        │
        Request Attempt 2
            │
            ├─ Success? → Return data
            │
            └─ Failure? → Wait 2000ms
                │
                Request Attempt 3
                    │
                    ├─ Success? → Return data
                    │
                    └─ Failure? → Wait 4000ms
                        │
                        Request Attempt 4
                            │
                            ├─ Success? → Return data
                            │
                            └─ Failure? → Throw error
```

**Key Function**:
```typescript
async function fetchWithRetry<T>(
    url: string,
    options?: RetryOptions
): Promise<T>
```

**Configuration**:
```typescript
{
    maxRetries: 3,              // Total attempts: 4 (1 initial + 3 retries)
    initialDelayMs: 1000,       // Start with 1 second
    maxDelayMs: 30000,          // Cap at 30 seconds
    backoffMultiplier: 2        // Double delay each time
}
```

**Exponential Backoff Formula**:
```
delay = min(initialDelay * (multiplier ^ attempt), maxDelay)

Attempt 1: min(1000 * 2^0, 30000) = 1000ms
Attempt 2: min(1000 * 2^1, 30000) = 2000ms
Attempt 3: min(1000 * 2^2, 30000) = 4000ms
Attempt 4: min(1000 * 2^3, 30000) = 8000ms
```

---

### 3. **Batch Processor** (`lib/batch-processor.ts`)

**Purpose**: Process large arrays in memory-efficient batches

**Architecture**:
```
Input: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
Batch Size: 5

┌─────────────────────────────────────────────────────────┐
│                  Async Generator                        │
├─────────────────────────────────────────────────────────┤
│  Yield 1: [1, 2, 3, 4, 5]                              │
│           ↓ Process batch                               │
│  Yield 2: [6, 7, 8, 9, 10]                             │
│           ↓ Process batch                               │
│  Yield 3: [11, 12, 13, 14, 15]                         │
│           ↓ Process batch                               │
│  Yield 4: [16, 17]                                     │
│           ↓ Process batch                               │
│  Done                                                   │
└─────────────────────────────────────────────────────────┘
```

**Key Function**:
```typescript
async function* batchGenerator<T>(
    items: T[],
    batchSize: number
): AsyncGenerator<T[], void, unknown>
```

**Benefits**:
- ✅ Prevents memory spikes
- ✅ Allows progressive processing
- ✅ Better error isolation (one batch fails, others continue)
- ✅ Easier to track progress

---

### 4. **Category Sync Workflow** (`workflows/sync-categories.ts`)

**Purpose**: Sync product categories from external API to Medusa

**Architecture**:
```
┌─────────────────────────────────────────────────────────┐
│              syncCategoriesWorkflow                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Input: { categories: CategoryInput[] }                │
│         [{ name: "beauty", slug: "beauty" }, ...]       │
│                                                         │
│  ┌───────────────────────────────────────────────┐     │
│  │         syncCategoriesStep                    │     │
│  ├───────────────────────────────────────────────┤     │
│  │                                               │     │
│  │  1. Query existing categories                │     │
│  │     ↓                                         │     │
│  │  2. Build existing map (handle → id)         │     │
│  │     ↓                                         │     │
│  │  3. Filter: Which are new?                   │     │
│  │     ↓                                         │     │
│  │  4. Create new categories                    │     │
│  │     (using createProductCategoriesWorkflow)  │     │
│  │     ↓                                         │     │
│  │  5. Update map with new IDs                  │     │
│  │     ↓                                         │     │
│  │  6. Return result                            │     │
│  │                                               │     │
│  └───────────────────────────────────────────────┘     │
│                                                         │
│  Output: {                                              │
│    created: number,                                     │
│    existing: number,                                    │
│    categoryMap: Record<string, string>                  │
│  }                                                      │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Compensation (Rollback)**:
If the workflow fails, it automatically deletes any categories created during this run.

---

### 5. **Medusa Core Workflows**

**Purpose**: Built-in Medusa workflows for product operations

#### `createProductsWorkflow`
```typescript
import { createProductsWorkflow } from "@medusajs/medusa/core-flows"

await createProductsWorkflow(container).run({
    input: { products: [...] }
})
```

**What it does**:
- Validates product data
- Creates products in database
- Creates variants
- Sets prices
- Uploads images (if applicable)
- Handles transactions
- Automatic rollback on error

#### `updateProductsWorkflow`
```typescript
import { updateProductsWorkflow } from "@medusajs/medusa/core-flows"

await updateProductsWorkflow(container).run({
    input: { products: [{ id: "...", data: {...} }] }
})
```

**What it does**:
- Validates update data
- Updates product fields
- Handles variant updates
- Manages price changes
- Handles transactions
- Automatic rollback on error

---

## 🔄 Data Flow Architecture

### Pagination Flow

```
┌──────────────────────────────────────────────────────────┐
│              fetchAllProducts()                          │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Initialize:                                             │
│  • allProducts = []                                      │
│  • skip = 0                                              │
│  • hasMore = true                                        │
│                                                          │
│  ┌────────────────────────────────────────────────┐     │
│  │  WHILE hasMore                                 │     │
│  │  ┌──────────────────────────────────────────┐  │     │
│  │  │  1. Build URL:                           │  │     │
│  │  │     ?limit=30&skip={skip}                │  │     │
│  │  │                                          │  │     │
│  │  │  2. Fetch with retry:                    │  │     │
│  │  │     response = fetchWithRetry(url)       │  │     │
│  │  │                                          │  │     │
│  │  │  3. Add to collection:                   │  │     │
│  │  │     allProducts.push(...response.products)│ │     │
│  │  │                                          │  │     │
│  │  │  4. Update pagination:                   │  │     │
│  │  │     skip += 30                           │  │     │
│  │  │     hasMore = (allProducts.length < total)│ │     │
│  │  │                                          │  │     │
│  │  │  5. Log progress                         │  │     │
│  │  └──────────────────────────────────────────┘  │     │
│  └────────────────────────────────────────────────┘     │
│                                                          │
│  Return: allProducts (194 items)                         │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

---

### Transformation Flow

```
┌──────────────────────────────────────────────────────────┐
│           mapToMedusaFormat(product)                     │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Input: DummyJSONProduct                                 │
│  {                                                       │
│    id: 1,                                                │
│    title: "iPhone 9",                                    │
│    price: 549,                                           │
│    category: "smartphones",                              │
│    ...                                                   │
│  }                                                       │
│                                                          │
│  ┌────────────────────────────────────────────────┐     │
│  │  Transformations:                              │     │
│  │                                                │     │
│  │  1. Generate handle:                           │     │
│  │     "iPhone 9" → "iphone-9"                    │     │
│  │                                                │     │
│  │  2. Convert price to cents:                    │     │
│  │     549 → 54900                                │     │
│  │                                                │     │
│  │  3. Wrap images in objects:                    │     │
│  │     ["url1", "url2"] → [{url:"url1"}, ...]     │     │
│  │                                                │     │
│  │  4. Create default variant:                    │     │
│  │     { title: "Default", prices: [...] }        │     │
│  │                                                │     │
│  │  5. Store external data in metadata:           │     │
│  │     { external_id: "1", category: "..." }      │     │
│  └────────────────────────────────────────────────┘     │
│                                                          │
│  Output: MedusaProductInput                              │
│  {                                                       │
│    title: "iPhone 9",                                    │
│    handle: "iphone-9",                                   │
│    variants: [{...}],                                    │
│    metadata: {...},                                      │
│    ...                                                   │
│  }                                                       │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

---

### Idempotency Flow

```
┌──────────────────────────────────────────────────────────┐
│         Idempotency Check (Prevent Duplicates)           │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  For each external product:                              │
│                                                          │
│  ┌────────────────────────────────────────────────┐     │
│  │  1. Get external_id from product               │     │
│  │     external_id = "1"                          │     │
│  │                                                │     │
│  │  2. Check if exists in Medusa                  │     │
│  │     existing = existingProductMap.get("1")     │     │
│  │                                                │     │
│  │  3. Decision:                                  │     │
│  │                                                │     │
│  │     ┌─────────────┐                            │     │
│  │     │  Exists?    │                            │     │
│  │     └──────┬──────┘                            │     │
│  │            │                                   │     │
│  │      ┌─────┴─────┐                             │     │
│  │      │           │                             │     │
│  │     YES         NO                             │     │
│  │      │           │                             │     │
│  │      ▼           ▼                             │     │
│  │  ┌───────┐  ┌────────┐                         │     │
│  │  │UPDATE │  │CREATE  │                         │     │
│  │  │ list  │  │ list   │                         │     │
│  │  └───────┘  └────────┘                         │     │
│  │      │           │                             │     │
│  │      │           └─ Ensure unique handle       │     │
│  │      │           └─ Link to category           │     │
│  │      │                                         │     │
│  │      └─ Keep existing handle                   │     │
│  │      └─ Update other fields                    │     │
│  │                                                │     │
│  └────────────────────────────────────────────────┘     │
│                                                          │
│  Result:                                                 │
│  • productsToCreate: MedusaProductInput[]                │
│  • productsToUpdate: { id, data }[]                      │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

---

## 🎯 Design Patterns Used

### 1. **Async Generator Pattern**
Used in `batchGenerator()` for memory-efficient iteration

### 2. **Retry Pattern with Exponential Backoff**
Used in `fetchWithRetry()` for resilient network requests

### 3. **Workflow Pattern**
Used in Medusa workflows for transactional operations with automatic rollback

### 4. **Map-Reduce Pattern**
Used for transforming and categorizing products

### 5. **Idempotent Operations**
Ensures safe re-execution without side effects

---

**Next**: [03-data-flow.md](./03-data-flow.md) - Detailed data flow diagrams
