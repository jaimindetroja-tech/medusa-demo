# 🔄 Data Flow Diagrams

## 📊 Complete End-to-End Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         CRON TRIGGER                                    │
│                      Daily at 00:00 (Midnight)                          │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    START: syncProductsJob()                             │
│                    Log: "🚀 Starting product sync job..."               │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   PHASE 1: FETCH ALL PRODUCTS                           │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  fetchAllProducts()                                                     │
│  │                                                                      │
│  ├─ Page 1: GET https://dummyjson.com/products?limit=30&skip=0         │
│  │  ├─ fetchWithRetry() [Max 3 retries]                                │
│  │  └─ Response: { products: [...30 items], total: 194 }               │
│  │                                                                      │
│  ├─ Page 2: GET https://dummyjson.com/products?limit=30&skip=30        │
│  │  ├─ fetchWithRetry() [Max 3 retries]                                │
│  │  └─ Response: { products: [...30 items], total: 194 }               │
│  │                                                                      │
│  ├─ Page 3: GET https://dummyjson.com/products?limit=30&skip=60        │
│  │  └─ ... continues until skip >= total                               │
│  │                                                                      │
│  └─ Page 7: GET https://dummyjson.com/products?limit=30&skip=180       │
│     └─ Response: { products: [...14 items], total: 194 }               │
│                                                                         │
│  Result: 194 products fetched                                           │
│  Log: "🎉 Successfully fetched 194 total products"                     │
│                                                                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│              PHASE 2: SYNC CATEGORIES (Bar Raiser)                      │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Extract unique categories from 194 products:                           │
│  • beauty, fragrances, furniture, groceries, home-decoration,           │
│    kitchen-accessories, laptops, mens-shirts, mens-shoes,               │
│    mens-watches, mobile-accessories, motorcycle, skin-care,             │
│    smartphones, sports-accessories, sunglasses, tablets,                │
│    tops, vehicle, womens-bags, womens-dresses, womens-jewellery,        │
│    womens-shoes, womens-watches                                         │
│                                                                         │
│  Total: 24 unique categories                                            │
│                                                                         │
│  syncCategoriesWorkflow.run({ categories: [...] })                      │
│  │                                                                      │
│  ├─ Query existing categories from Medusa                               │
│  │  query.graph({ entity: "product_category" })                         │
│  │                                                                      │
│  ├─ Build map: handle → id                                              │
│  │  { "beauty": "cat_01...", "fragrances": "cat_02...", ... }           │
│  │                                                                      │
│  ├─ Filter new categories (not in map)                                  │
│  │  First run: All 24 are new                                           │
│  │  Second run: 0 are new (idempotent!)                                 │
│  │                                                                      │
│  ├─ Create new categories                                               │
│  │  createProductCategoriesWorkflow.run({                               │
│  │    product_categories: [                                             │
│  │      { name: "Beauty", handle: "beauty", is_active: true },          │
│  │      { name: "Fragrances", handle: "fragrances", is_active: true },  │
│  │      ...                                                             │
│  │    ]                                                                 │
│  │  })                                                                  │
│  │                                                                      │
│  └─ Return categoryMap: { slug → id }                                   │
│                                                                         │
│  Result: { created: 24, existing: 0, categoryMap: {...} }               │
│  Log: "✅ Categories synced: 24 created, 0 existing"                   │
│                                                                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│           PHASE 3: CHECK EXISTING PRODUCTS (Idempotency)                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Query Medusa database for existing products:                           │
│  query.graph({                                                          │
│    entity: "product",                                                   │
│    fields: ["id", "handle", "metadata"]                                 │
│  })                                                                     │
│                                                                         │
│  First run: 0 products                                                  │
│  Second run: 194 products                                               │
│                                                                         │
│  Build maps:                                                            │
│  ┌─────────────────────────────────────────────────────────┐            │
│  │ existingProductMap: Map<external_id, product>           │            │
│  │ {                                                       │            │
│  │   "1" → { id: "prod_01...", handle: "iphone-9", ... }  │            │
│  │   "2" → { id: "prod_02...", handle: "iphone-x", ... }  │            │
│  │   ...                                                   │            │
│  │ }                                                       │            │
│  └─────────────────────────────────────────────────────────┘            │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────┐            │
│  │ dbHandles: Set<string>                                  │            │
│  │ { "iphone-9", "iphone-x", "samsung-universe-9", ... }   │            │
│  └─────────────────────────────────────────────────────────┘            │
│                                                                         │
│  Log: "📊 Found 0 existing products in Medusa" (first run)             │
│       "📊 Found 194 existing products in Medusa" (second run)          │
│                                                                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│        PHASE 4: TRANSFORM & CATEGORIZE PRODUCTS                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  For each of 194 products:                                              │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────┐     │
│  │  Product #1: { id: 1, title: "iPhone 9", ... }               │     │
│  │                                                               │     │
│  │  1. Transform to Medusa format:                               │     │
│  │     mapToMedusaFormat(product)                                │     │
│  │     → { title: "iPhone 9", handle: "iphone-9", ... }          │     │
│  │                                                               │     │
│  │  2. Check if exists:                                          │     │
│  │     existing = existingProductMap.get("1")                    │     │
│  │                                                               │     │
│  │  3a. IF EXISTS (Second run):                                  │     │
│  │      • Keep existing handle: "iphone-9"                       │     │
│  │      • Add to UPDATE list:                                    │     │
│  │        productsToUpdate.push({                                │     │
│  │          id: "prod_01...",                                    │     │
│  │          data: { title, description, metadata, ... }          │     │
│  │        })                                                     │     │
│  │                                                               │     │
│  │  3b. IF NEW (First run):                                      │     │
│  │      • Ensure unique handle:                                  │     │
│  │        - Check usedHandles and dbHandles                      │     │
│  │        - If collision: append counter                         │     │
│  │          "iphone-9" → "iphone-9-1" → "iphone-9-2"             │     │
│  │      • Link to category:                                      │     │
│  │        category_ids = [categoryMap["smartphones"]]            │     │
│  │      • Add to CREATE list:                                    │     │
│  │        productsToCreate.push(product)                         │     │
│  │                                                               │     │
│  └───────────────────────────────────────────────────────────────┘     │
│                                                                         │
│  Result (First run):                                                    │
│  • productsToCreate: 194 items                                          │
│  • productsToUpdate: 0 items                                            │
│                                                                         │
│  Result (Second run):                                                   │
│  • productsToCreate: 0 items                                            │
│  • productsToUpdate: 194 items                                          │
│                                                                         │
│  Log: "📝 194 products to create" (first run)                          │
│       "🔄 0 products to update"                                        │
│                                                                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│              PHASE 5: BATCH PROCESSING - CREATE                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  IF productsToCreate.length > 0:                                        │
│                                                                         │
│  for await (const batch of batchGenerator(productsToCreate, 15)) {      │
│                                                                         │
│    ┌─────────────────────────────────────────────────────────┐         │
│    │  Batch 1: Products 1-15                                 │         │
│    │                                                         │         │
│    │  createProductsWorkflow(container).run({                │         │
│    │    input: { products: [                                 │         │
│    │      { title: "iPhone 9", handle: "iphone-9", ... },    │         │
│    │      { title: "iPhone X", handle: "iphone-x", ... },    │         │
│    │      ... (15 products)                                  │         │
│    │    ]}                                                   │         │
│    │  })                                                     │         │
│    │                                                         │         │
│    │  ✅ Success: createdCount += 15                         │         │
│    │  Log: "✅ Batch 1: Created 15 products (15/194)"       │         │
│    └─────────────────────────────────────────────────────────┘         │
│                                                                         │
│    ┌─────────────────────────────────────────────────────────┐         │
│    │  Batch 2: Products 16-30                                │         │
│    │  ... (same process)                                     │         │
│    │  Log: "✅ Batch 2: Created 15 products (30/194)"       │         │
│    └─────────────────────────────────────────────────────────┘         │
│                                                                         │
│    ... continues for 13 batches total ...                               │
│                                                                         │
│    ┌─────────────────────────────────────────────────────────┐         │
│    │  Batch 13: Products 181-194 (14 products)               │         │
│    │  ... (same process)                                     │         │
│    │  Log: "✅ Batch 13: Created 14 products (194/194)"     │         │
│    └─────────────────────────────────────────────────────────┘         │
│  }                                                                      │
│                                                                         │
│  Result: createdCount = 194                                             │
│                                                                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│              PHASE 6: BATCH PROCESSING - UPDATE                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  IF productsToUpdate.length > 0:                                        │
│                                                                         │
│  for await (const batch of batchGenerator(productsToUpdate, 15)) {      │
│                                                                         │
│    ┌─────────────────────────────────────────────────────────┐         │
│    │  Batch 1: Products 1-15                                 │         │
│    │                                                         │         │
│    │  updateProductsWorkflow(container).run({                │         │
│    │    input: { products: [                                 │         │
│    │      {                                                  │         │
│    │        id: "prod_01...",                                │         │
│    │        data: { title: "...", description: "...", ... }  │         │
│    │      },                                                 │         │
│    │      ... (15 products)                                  │         │
│    │    ]}                                                   │         │
│    │  })                                                     │         │
│    │                                                         │         │
│    │  ✅ Success: updatedCount += 15                         │         │
│    │  Log: "✅ Batch 1: Updated 15 products (15/194)"       │         │
│    └─────────────────────────────────────────────────────────┘         │
│                                                                         │
│    ... continues for all batches ...                                    │
│  }                                                                      │
│                                                                         │
│  Result: updatedCount = 194 (on second run)                             │
│                                                                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    PHASE 7: FINAL SUMMARY                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Calculate duration:                                                    │
│  duration = (Date.now() - startTime) / 1000                             │
│                                                                         │
│  Log Summary:                                                           │
│  ============================================================            │
│  🎉 Product sync completed!                                            │
│  ============================================================            │
│  ✅ Created: 194                                                        │
│  🔄 Updated: 0                                                          │
│  ❌ Errors: 0                                                           │
│  ⏱️  Duration: 12.34s                                                  │
│  ============================================================            │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🔁 Retry Flow (Detailed)

```
┌─────────────────────────────────────────────────────────────┐
│        fetchWithRetry("https://dummyjson.com/...")         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Attempt 1 (Initial)                                        │
│  ├─ fetch(url)                                              │
│  │                                                          │
│  ├─ SUCCESS? ────────────────────────────────┐              │
│  │   └─ Return data                          │              │
│  │                                            │              │
│  └─ FAILURE? (Network error, 500, timeout)   │              │
│      │                                        │              │
│      ├─ Log: "⚠️  Attempt 1/4 failed"        │              │
│      ├─ Calculate delay: 1000ms              │              │
│      └─ Wait 1000ms                          │              │
│                                              │              │
│  Attempt 2                                   │              │
│  ├─ fetch(url)                               │              │
│  │                                           │              │
│  ├─ SUCCESS? ─────────────────────────────┐  │              │
│  │   └─ Return data                       │  │              │
│  │                                         │  │              │
│  └─ FAILURE?                               │  │              │
│      │                                     │  │              │
│      ├─ Log: "⚠️  Attempt 2/4 failed"     │  │              │
│      ├─ Calculate delay: 2000ms           │  │              │
│      └─ Wait 2000ms                       │  │              │
│                                            │  │              │
│  Attempt 3                                 │  │              │
│  ├─ fetch(url)                             │  │              │
│  │                                         │  │              │
│  ├─ SUCCESS? ───────────────────────────┐  │  │              │
│  │   └─ Return data                     │  │  │              │
│  │                                       │  │  │              │
│  └─ FAILURE?                             │  │  │              │
│      │                                   │  │  │              │
│      ├─ Log: "⚠️  Attempt 3/4 failed"   │  │  │              │
│      ├─ Calculate delay: 4000ms         │  │  │              │
│      └─ Wait 4000ms                     │  │  │              │
│                                          │  │  │              │
│  Attempt 4 (Final)                       │  │  │              │
│  ├─ fetch(url)                           │  │  │              │
│  │                                       │  │  │              │
│  ├─ SUCCESS? ─────────────────────────┐  │  │  │              │
│  │   └─ Return data                   │  │  │  │              │
│  │                                     │  │  │  │              │
│  └─ FAILURE?                           │  │  │  │              │
│      └─ Throw Error                    │  │  │  │              │
│         "Failed after 4 attempts"      │  │  │  │              │
│                                        │  │  │  │              │
│                                        ▼  ▼  ▼  ▼              │
│                                   Return Data                 │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

---

## 📦 Batch Processing Flow

```
Input: 194 products
Batch Size: 15

┌─────────────────────────────────────────────────────────────┐
│           batchGenerator(products, 15)                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Memory State:                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Heap: ~50MB (only 15 products in memory at a time) │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Iteration 1:                                               │
│  ├─ Slice: products[0:15]                                   │
│  ├─ Yield: [Product 1, Product 2, ..., Product 15]          │
│  └─ Process batch → createProductsWorkflow()                │
│      └─ Memory freed after processing                       │
│                                                             │
│  Iteration 2:                                               │
│  ├─ Slice: products[15:30]                                  │
│  ├─ Yield: [Product 16, Product 17, ..., Product 30]        │
│  └─ Process batch → createProductsWorkflow()                │
│      └─ Memory freed after processing                       │
│                                                             │
│  ... continues ...                                          │
│                                                             │
│  Iteration 13:                                              │
│  ├─ Slice: products[180:194]                                │
│  ├─ Yield: [Product 181, Product 182, ..., Product 194]     │
│  └─ Process batch → createProductsWorkflow()                │
│      └─ Memory freed after processing                       │
│                                                             │
│  Done                                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘

VS. Without Batching:

┌─────────────────────────────────────────────────────────────┐
│  ❌ Process all 194 products at once                        │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Heap: ~650MB (all products in memory)              │   │
│  │ Risk: Out of memory errors                         │   │
│  │ Risk: Slow processing                              │   │
│  │ Risk: If one fails, all fail                       │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎭 Idempotency Flow (First vs Second Run)

### First Run (No existing products)

```
External Products: 194
Existing Products: 0

For each product:
  existing = existingProductMap.get(external_id)
  → undefined (not found)
  
  → Add to CREATE list
  
Result:
  productsToCreate: 194
  productsToUpdate: 0
  
Action:
  Create 194 products in Medusa
```

### Second Run (All products exist)

```
External Products: 194
Existing Products: 194

For each product:
  existing = existingProductMap.get(external_id)
  → { id: "prod_01...", handle: "iphone-9", ... } (found!)
  
  → Add to UPDATE list
  
Result:
  productsToCreate: 0
  productsToUpdate: 194
  
Action:
  Update 194 products in Medusa
  (No duplicates created!)
```

---

## 🔗 Category Linking Flow

```
Product: { id: 1, title: "iPhone 9", category: "smartphones" }

┌─────────────────────────────────────────────────────────────┐
│              Category Linking Process                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Get category name from product:                         │
│     category = "smartphones"                                │
│                                                             │
│  2. Generate category slug:                                 │
│     slug = "smartphones"                                    │
│            .toLowerCase()                                   │
│            .replace(/[^a-z0-9]+/g, "-")                     │
│     → "smartphones"                                         │
│                                                             │
│  3. Look up category ID in map:                             │
│     categoryMap = {                                         │
│       "smartphones": "cat_01JGXXX...",                      │
│       "laptops": "cat_01JGYYY...",                          │
│       ...                                                   │
│     }                                                       │
│     categoryId = categoryMap["smartphones"]                 │
│     → "cat_01JGXXX..."                                      │
│                                                             │
│  4. Add to product:                                         │
│     product.category_ids = ["cat_01JGXXX..."]               │
│                                                             │
│  5. When product is created:                                │
│     Medusa automatically creates the link:                  │
│     product_category_product table:                         │
│     ┌──────────────┬─────────────────┐                     │
│     │ product_id   │ category_id     │                     │
│     ├──────────────┼─────────────────┤                     │
│     │ prod_01...   │ cat_01JGXXX...  │                     │
│     └──────────────┴─────────────────┘                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚨 Error Handling Flow

```
┌─────────────────────────────────────────────────────────────┐
│                  Error Handling Strategy                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Level 1: Network Errors (fetchWithRetry)                   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Try → Fail → Retry → Fail → Retry → Fail → Throw  │   │
│  │  Handles: Timeouts, 500 errors, network issues     │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Level 2: Category Sync Errors                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  try {                                              │   │
│  │    syncCategoriesWorkflow()                         │   │
│  │  } catch (error) {                                  │   │
│  │    Log warning                                      │   │
│  │    Continue with product sync                       │   │
│  │    (Products won't have categories, but will sync)  │   │
│  │  }                                                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Level 3: Batch Processing Errors                           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  for each batch {                                   │   │
│  │    try {                                            │   │
│  │      createProductsWorkflow(batch)                  │   │
│  │    } catch (error) {                                │   │
│  │      Log error                                      │   │
│  │      errorCount += batch.length                     │   │
│  │      Continue with next batch                       │   │
│  │      (One batch fails, others continue)             │   │
│  │    }                                                │   │
│  │  }                                                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Level 4: Job-Level Errors                                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  try {                                              │   │
│  │    // Entire sync process                          │   │
│  │  } catch (error) {                                  │   │
│  │    Log: "💥 Product sync failed"                   │   │
│  │    throw error (job marked as failed)              │   │
│  │  }                                                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

**Next**: [04-implementation.md](./04-implementation.md) - Step-by-step implementation guide
